"""Read-only phone dashboard for the EMA 10/50/90 paper account (reads the real SQLite DB)."""
from __future__ import annotations
import html, json, sqlite3, time
from datetime import datetime, timezone, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

LOCAL = timezone(timedelta(hours=3, minutes=30))
INITIAL = None


def _rows(db, sql):
    try:
        with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as c:
            return c.execute(sql).fetchall()
    except sqlite3.Error:
        return []


def stats(db):
    """Trade statistics derived only from broker events (closed trades pair OPEN->close by symbol)."""
    ev = _rows(db, "SELECT side,symbol,pnl,fee,timestamp FROM events ORDER BY rowid")
    pnls, open_fee = [], {}
    for side, sym, pnl, fee, _ts in ev:          # full trade PnL = close net pnl - open-leg fee
        if side == "SHORT_OPEN": open_fee[sym] = fee
        else: pnls.append(pnl - open_fee.pop(sym, 0.0))
    wins = [x for x in pnls if x > 0]; losses = [x for x in pnls if x <= 0]
    return {"trades": len(pnls), "wins": len(wins), "losses": len(losses),
            "win_rate": (len(wins) / len(pnls) * 100) if pnls else None,
            "avg_win": sum(wins) / len(wins) if wins else None,
            "avg_loss": sum(losses) / len(losses) if losses else None,
            "best": max(pnls) if pnls else None, "worst": min(pnls) if pnls else None,
            "fees": sum(e[3] for e in ev), "net_closed": sum(pnls)}


def render(db_path, heartbeat_path=None):
    db = str(db_path)
    acct = _rows(db, "SELECT cash FROM account WHERE id=1")
    cash = acct[0][0] if acct else None
    positions = _rows(db, "SELECT symbol,quantity,entry,stop,opened_at FROM positions")
    marks = dict(_rows(db, "SELECT symbol,price FROM ema_marks"))
    status = _rows(db, "SELECT symbol,bar_ts,action,price,ema10,ema50,ema90,stoch_k,stoch_d FROM ema_status ORDER BY symbol")
    snaps = _rows(db, "SELECT ts,equity FROM ema_snapshots ORDER BY ts")
    alerts = _rows(db, "SELECT symbol,ts,state,reason FROM ema_alerts")
    events = _rows(db, "SELECT side,symbol,quantity,price,pnl,timestamp FROM events ORDER BY rowid DESC LIMIT 20")
    unreal = sum((e - marks.get(s, e)) * q for s, q, e, st, o in positions)
    equity = (cash + unreal) if cash is not None else None
    peak, dd = -1e18, 0.0
    for _, v in snaps:
        peak = max(peak, v); dd = min(dd, v / peak - 1 if peak > 0 else 0)
    hb = None
    if heartbeat_path and Path(heartbeat_path).exists():
        try: hb = int(time.time()) - int(json.loads(Path(heartbeat_path).read_text(encoding="utf-8")).get("time", 0))
        except (OSError, ValueError, TypeError): hb = None
    st = stats(db)
    f = lambda v, n=2: "-" if v is None else f"{v:.{n}f}"
    fmt = lambda ts: datetime.fromtimestamp(int(ts), LOCAL).strftime("%m-%d %H:%M")
    esc = lambda x: html.escape(str(x))

    def table(h, rows):
        if not rows: return "<p>هنوز داده‌ای ثبت نشده است.</p>"
        return ('<div style="overflow-x:auto"><table><tr>' + "".join(f"<th>{esc(x)}</th>" for x in h) + "</tr>" +
                "".join("<tr>" + "".join(f"<td>{esc(x)}</td>" for x in r) + "</tr>" for r in rows) + "</table></div>")
    cards = "".join(f'<div class="card"><b>{v}</b><span>{k}</span></div>' for k, v in [
        ("ارزش حساب", f(equity)), ("نقد", f(cash)), ("سود/زیان تحقق‌نیافته", f(unreal)),
        ("افت سرمایه", f"{dd*100:.2f}%"), ("معاملات بسته", st["trades"]),
        ("نرخ برد", "-" if st["win_rate"] is None else f'{st["win_rate"]:.0f}%'),
        ("میانگین سود/زیان", f'{f(st["avg_win"])} / {f(st["avg_loss"])}'), ("کارمزد کل", f(st["fees"])),
        ("heartbeat", "ناموجود" if hb is None else f"{hb} ثانیه قبل")])
    warn = "".join(f"<p><b>{esc(s)}: {esc(a)}</b> — {esc(r)}</p>" for s, t, a, r in alerts)
    if not warn and hb is not None and hb > 180: warn = "<p><b>هشدار:</b> heartbeat قدیمی است؛ سرویس ممکن است متوقف باشد.</p>"
    mk = [(s, fmt(t), a, f"{p:.6g}", f"{e10:.6g}", f"{e50:.6g}", f"{e90:.6g}", f"{k:.0f}/{d:.0f}") for s, t, a, p, e10, e50, e90, k, d in status]
    ps = [(s, f"{q:.6g}", f"{e:.6g}", f"{stp:.6g}", f"{marks.get(s, e):.6g}", f"{(e-marks.get(s,e))*q:.4f}", fmt(o)) for s, q, e, stp, o in positions]
    ev = [(a, s, f"{q:.6g}", f"{p:.6g}", f"{n:.4f}", fmt(t)) for a, s, q, p, n, t in events]
    return f'''<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="30"><title>MABOT EMA 10/50/90</title><style>body{{font-family:Tahoma,system-ui;margin:0;padding:16px;background:#f4f6f8;color:#20242a}}h1{{font-size:21px}}h2{{font-size:16px;margin-top:22px}}.grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin:14px 0}}.card{{background:#fff;padding:13px;border-radius:10px}}.card b{{display:block;font-size:20px}}.card span{{font-size:13px;color:#667}}table{{border-collapse:collapse;background:#fff;width:100%}}td,th{{padding:8px;border-bottom:1px solid #ddd;text-align:right;white-space:nowrap;font-size:12px}}.notice{{padding:12px;background:#fff1d5;border-radius:9px;margin-top:18px;font-size:13px}}@media(prefers-color-scheme:dark){{body{{background:#15171b;color:#eee}}.card,table{{background:#22262d}}td,th{{border-color:#393e47}}.notice{{background:#382d17}}}}</style><h1>MABOT — EMA 10/50/90 (Short، ۱۵ دقیقه)</h1><div>فقط شبیه‌سازی؛ بدون سفارش واقعی. همه اعداد از دیتابیس خوانده می‌شوند.</div><div class="grid">{cards}</div><h2>هشدارها</h2><div class="notice">{warn or "هشدار فعالی نیست."}</div><h2>وضعیت نمادها</h2>{table(["نماد","کندل","وضعیت","قیمت","EMA10","EMA50","EMA90","Stoch K/D"],mk)}<h2>پوزیشن‌های باز</h2>{table(["نماد","مقدار","ورود","حدضرر","قیمت فعلی","سود/زیان","زمان"],ps)}<h2>آخرین رویدادها</h2>{table(["نوع","نماد","مقدار","قیمت","سود/زیان خالص","زمان"],ev)}<div class="notice">نسخه آزمایشی؛ هنوز بک‌تست ۱۵ دقیقه‌ای ندارد. نتیجه شبیه‌سازی تضمین سود نیست.</div></html>'''


def serve(db, beat, host="127.0.0.1", port=8085):
    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path.split("?")[0] not in ("/", "/index.html"): self.send_error(404); return
            body = render(db, beat).encode(); self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(body)))
            self.end_headers(); self.wfile.write(body)
        def log_message(self, *a): pass
    return ThreadingHTTPServer((host, port), H)
