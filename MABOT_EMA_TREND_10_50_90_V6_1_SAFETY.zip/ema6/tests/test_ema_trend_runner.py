import sqlite3
import numpy as np
import pandas as pd
import paper_trading.ema_trend_runner as RR
from paper_trading.ema_trend_runner import EMATrendPaperRunner

END = 1_800_000_000 // 900 * 900


def bars(n=300, spike=None, drop=(), step=900):
    ts = END - step * np.arange(n)[::-1]
    df = pd.DataFrame(dict(timestamp=ts, open=100.0, high=100.3, low=99.7, close=100.0, volume=1.0))
    if spike: df.loc[df.timestamp == spike[0], "high"] = spike[1]
    return df[~df.timestamp.isin(drop)].reset_index(drop=True)


class Client:
    def __init__(self, df15, df5=None): self.df15, self.df5 = df15, df5
    def fetch_closed(self, sym, tf):
        if tf == "15m": return self.df15
        if self.df5 is None: raise RuntimeError("no 5m")
        return self.df5


def mk(tmp_path, df, df5=None):
    r = EMATrendPaperRunner(tmp_path / "t.sqlite3", client=Client(df, df5), symbols=["BTCUSDT"])
    r.broker.open_short("x", "BTCUSDT", 100.0, 1.0, 101.0, END - 900 * 5)
    return r


def test_stop_in_non_latest_bar_is_still_executed(tmp_path):
    r = mk(tmp_path, bars())
    r.client = Client(bars(spike=(END - 900 * 3, 102.0)))
    assert r.run_once()[0]["action"] == "PAPER_STOP"
    assert not r.broker.positions()


def test_gap_in_old_bars_does_not_disable_stop_monitoring(tmp_path):
    r = mk(tmp_path, bars())
    r.client = Client(bars(drop=(END - 900 * 100,), spike=(END, 103.0)))
    assert r.run_once()[0]["action"] == "PAPER_STOP"


def test_missing_bar_after_entry_resolved_by_5m_fallback(tmp_path):
    r = mk(tmp_path, bars())
    m = END - 900 * 2
    five = bars(300 * 3, step=300); five.loc[five.timestamp == m + 300, "high"] = 102.0
    r.client = Client(bars(drop=(m,)), five)
    assert r.run_once()[0]["action"] == "PAPER_STOP"


def test_missing_bar_without_any_data_forces_conservative_cover(tmp_path):
    r = mk(tmp_path, bars())
    r.client = Client(bars(drop=(END, END - 900 * 2)))      # hole in the middle, no 5m available
    assert r.run_once()[0]["action"] == "PAPER_GAP_EXIT"
    assert not r.broker.positions()
    assert r._q("SELECT state FROM ema_alerts")[0][0] == "STOP_DATA_GAP_COVERED"


def test_partial_5m_fallback_is_not_treated_as_verified(tmp_path):
    r = mk(tmp_path, bars())
    missing = END - 900 * 2
    fifteen = bars(drop=(missing,))
    five = bars(3, step=300)
    # Only two of the three 5m bars are present for the missing 15m interval.
    five = five.iloc[:2].copy()
    five["timestamp"] = [missing, missing + 600]
    r.client = Client(fifteen, five)
    assert r.run_once()[0]["action"] == "PAPER_GAP_EXIT"
    assert not r.broker.positions()
    event = r._q("SELECT side FROM events WHERE side='EMA_STOP_DATA_GAP_EXIT'")
    assert event


def test_no_reentry_on_same_bar_as_stop(tmp_path, monkeypatch):
    def fake(c, cfg):
        last = c.iloc[-1]
        return dict(ready=True, timestamp=int(last.timestamp) + 900, price=float(last.close), atr=0.5,
                    ema10=1, ema50=2, ema90=3, stoch_k=1, stoch_d=2, entry_signal=True, exit_signal=False,
                    action="SHORT_ENTRY", reason="forced")
    monkeypatch.setattr(RR, "evaluate", fake)
    r = mk(tmp_path, bars())
    r.client = Client(bars(spike=(END, 102.0)))
    acts = [r.run_once()[0]["action"] for _ in range(3)]
    assert acts[0] == "PAPER_STOP" and "PAPER_SHORT_OPEN" not in acts[1:]
    assert not r.broker.positions()


def test_equity_uses_persisted_marks_for_all_symbols(tmp_path):
    r = mk(tmp_path, bars())
    r._set_mark("BTCUSDT", 90.0, END)
    entry = r.broker.positions()["BTCUSDT"]["entry"]
    assert abs(r.broker.equity(r.marks()) - (r.broker.cash + (entry - 90.0))) < 1e-9


def test_dashboard_reads_real_db(tmp_path):
    from paper_trading.ema_dashboard import render
    r = mk(tmp_path, bars()); r.run_once()
    page = render(r.db_path)
    assert "BTCUSDT" in page and "ارزش حساب" in page


def test_full_replay_accounting_reconciles_and_trades_happen(tmp_path):
    """Feed a regime-change series bar by bar through the real runner (real strategy)."""
    import sys, os
    sys.path.insert(0, os.path.dirname(__file__))
    from test_ema_trend_10_50_90 import regime_change
    full = regime_change(n_up=300, n_dn=500)

    class Replay:
        i = 0
        def fetch_closed(self, sym, tf):
            if tf != "15m": raise RuntimeError("no 5m")
            return full.iloc[max(0, self.i - 299):self.i + 1].reset_index(drop=True)
    rp = Replay()
    r = EMATrendPaperRunner(tmp_path / "rp.sqlite3", client=rp, symbols=["BTCUSDT"])
    for i in range(130, len(full)):
        rp.i = i; r.run_once()
    ev = r._q("SELECT side,pnl FROM events")
    opens = [e for e in ev if e[0] == "SHORT_OPEN"]
    assert opens, "runner must open at least one short on a clean regime change"
    pos = r.broker.positions()
    if not pos:                                   # flat: cash must equal initial + sum of all event pnl
        assert abs(r.broker.cash - (100.0 + sum(e[1] for e in ev))) < 1e-6
    assert len(r._q("SELECT event_id FROM events")) == len({e[0] for e in r._q("SELECT event_id FROM events")})
