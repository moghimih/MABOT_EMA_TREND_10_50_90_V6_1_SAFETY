@echo off
cd /d %~dp0
if not exist .venv\Scripts\python.exe (
  echo Virtual environment not found. Create it and install requirements first.
  pause
  exit /b 1
)
rem Paper only. Dashboard: http://127.0.0.1:8085  (add --share for phone on same Wi-Fi)
.venv\Scripts\python.exe -m paper_trading.ema_trend_runner --interval 60
pause
