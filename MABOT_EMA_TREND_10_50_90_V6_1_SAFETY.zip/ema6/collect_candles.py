"""Public-data collector: appends closed 1m/5m/15m Nobitex candles to CSV (no API key, read-only).
Run it for weeks (python collect_candles.py), then backtest short ideas on REAL data before trusting them.
"""
import csv, sys, time
from pathlib import Path
import requests
URL = "https://apiv2.nobitex.ir/market/udf/history"
TF = {"1m": ("1", 60), "5m": ("5", 300), "15m": ("15", 900)}
SYMBOLS = ["BTCUSDT", "ETHUSDT", "ZECUSDT", "XRPUSDT"]
OUT = Path("data_mtf"); OUT.mkdir(exist_ok=True)

def last_ts(f):
    if not f.exists(): return 0
    last = 0
    with f.open() as fh:
        for row in csv.reader(fh):
            if row and row[0].isdigit(): last = int(row[0])
    return last

def pull(sym, tf):
    res, sec = TF[tf]; now = int(time.time())
    r = requests.get(URL, params={"symbol": sym, "resolution": res, "to": now, "countback": 300}, timeout=20)
    r.raise_for_status(); p = r.json()
    if p.get("s") != "ok": return 0
    f = OUT / f"{sym}_{tf}.csv"; new = not f.exists(); last = last_ts(f); n = 0
    with f.open("a", newline="") as fh:
        w = csv.writer(fh)
        if new: w.writerow(["timestamp", "open", "high", "low", "close", "volume"])
        for t, o, h, l, c, v in zip(p["t"], p["o"], p["h"], p["l"], p["c"], p["v"]):
            if int(t) > last and int(t) + sec <= now:   # closed candles only, never duplicated
                w.writerow([int(t), o, h, l, c, v]); n += 1
    return n

if __name__ == "__main__":
    once = "--once" in sys.argv
    while True:
        for s in SYMBOLS:
            for tf in TF:
                try: pull(s, tf)
                except Exception as e: print("warn", s, tf, e)
        print(time.strftime("%H:%M:%S"), "collected")
        if once: break
        time.sleep(3600)   # 300 x 1m candles = 5h window; hourly pull leaves no gaps
