import pandas as pd

from paper_trading.short_mtf import (
    ShortMTFRunner,
    _remaining_short_risk,
    _validate_candles,
)


def test_trailing_stop_does_not_make_portfolio_risk_negative():
    positions = {
        "BTCUSDT": {"quantity": 2.0, "entry": 100.0, "stop": 95.0}
    }
    risk = _remaining_short_risk(positions, fee_rate=0.001, slippage_rate=0.001)
    assert risk == 0.8


def test_zero_volume_is_valid_but_negative_volume_is_rejected():
    candles = pd.DataFrame({
        "timestamp": [60],
        "open": [100.0],
        "high": [101.0],
        "low": [99.0],
        "close": [100.0],
        "volume": [0.0],
    })
    assert len(_validate_candles(candles, "1m")) == 1

    candles.loc[0, "volume"] = -1.0
    try:
        _validate_candles(candles, "1m")
    except ValueError as exc:
        assert "negative" in str(exc).lower()
    else:
        raise AssertionError("Negative volume should be rejected")


def test_stop_is_checked_on_1m_and_is_idempotent(tmp_path):
    db_path = tmp_path / "paper.sqlite3"
    runner = ShortMTFRunner(db_path=str(db_path), client=object())
    assert runner.broker.open_short("seed", "TESTUSDT", 100.0, 1.0, 105.0, 1000)

    candles = pd.DataFrame({
        "timestamp": [1000, 1060],
        "open": [101.0, 107.0],  # second candle gaps above the stop
        "high": [103.0, 108.0],
        "low": [100.0, 106.0],
        "close": [102.0, 107.5],
        "volume": [0.0, 1.0],
    })

    assert runner._monitor_1m_stop("TESTUSDT", candles) == "PAPER_SHORT_STOP"
    assert "TESTUSDT" not in runner.broker.positions()

    # Reprocessing the same candle history must not create another cover.
    assert runner._monitor_1m_stop("TESTUSDT", candles) is None
    stop_events = [event for event in runner.broker.events() if event[1] == "SHORT_STOP"]
    assert len(stop_events) == 1
    # Stop fill uses the worse gap-open price, plus the configured paper slippage.
    assert stop_events[0][4] > 107.0



def test_missing_post_entry_minute_fails_closed(tmp_path):
    db_path = tmp_path / "paper.sqlite3"
    runner = ShortMTFRunner(db_path=str(db_path), client=object())
    assert runner.broker.open_short("seed-gap", "TESTUSDT", 100.0, 1.0, 105.0, 1000)
    # The first available post-entry candle starts at 1120, while 1060 is expected.
    candles = pd.DataFrame({
        "timestamp": [1120, 1180],
        "open": [101.0, 102.0], "high": [103.0, 104.0],
        "low": [100.0, 101.0], "close": [102.0, 103.0],
        "volume": [1.0, 1.0],
    })
    assert runner._monitor_1m_stop("TESTUSDT", candles) == "STOP_DATA_GAP"
    # No cover or signal-side action is allowed to mutate the open position.
    assert "TESTUSDT" in runner.broker.positions()
    assert not [event for event in runner.broker.events() if event[1] == "SHORT_STOP"]


def test_stop_monitor_runs_before_5m_15m_fetch_failure(tmp_path, monkeypatch):
    import paper_trading.short_mtf as module

    class Client:
        def fetch_closed(self, symbol, timeframe):
            if timeframe == "1m":
                return pd.DataFrame({
                    "timestamp": [1000, 1060],
                    "open": [101.0, 106.0], "high": [103.0, 108.0],
                    "low": [100.0, 105.0], "close": [102.0, 107.0],
                    "volume": [1.0, 1.0],
                })
            raise RuntimeError("signal timeframe offline")

    monkeypatch.setattr(module, "retry_call", lambda fn, **kwargs: fn())
    runner = ShortMTFRunner(tmp_path / "priority.db", client=Client())
    assert runner.broker.open_short("seed-priority", "BTCUSDT", 100, 1, 105, 1000)
    result = runner.run_once(["BTCUSDT"])[0]
    assert result["action"] == "PAPER_SHORT_STOP"
    assert "BTCUSDT" not in runner.broker.positions()


def test_unavailable_1m_stop_feed_persists_alert_and_blocks_signal(tmp_path, monkeypatch):
    import sqlite3
    import paper_trading.short_mtf as module

    class Client:
        def fetch_closed(self, symbol, timeframe):
            raise RuntimeError("1m feed unavailable")

    monkeypatch.setattr(module, "retry_call", lambda fn, **kwargs: fn())
    db = tmp_path / "alert.db"
    runner = ShortMTFRunner(db, client=Client())
    assert runner.broker.open_short("seed-alert", "BTCUSDT", 100, 1, 105, 1000)
    result = runner.run_once(["BTCUSDT"])[0]
    assert result["action"] == "STOP_MONITOR_UNAVAILABLE"
    assert "BTCUSDT" in runner.broker.positions()
    with sqlite3.connect(db) as con:
        alert = con.execute(
            "SELECT state FROM stop_monitor_alerts WHERE symbol='BTCUSDT'"
        ).fetchone()
    assert alert == ("STOP_MONITOR_UNAVAILABLE",)


def test_gap_is_resolved_by_5m_fallback_and_not_permanent(tmp_path):
    import numpy as np, pandas as pd
    from paper_trading.short_mtf import ShortMTFRunner
    end = 1_800_000_000 // 900 * 900

    def mk(step, drop=(), high_bump=None):
        ts = end - step * np.arange(300)[::-1]
        df = pd.DataFrame(dict(timestamp=ts, open=100.0, high=100.2, low=99.8, close=100.0, volume=1.0))
        if high_bump:
            df.loc[df.timestamp == high_bump[0], "high"] = high_bump[1]
        return df[~df.timestamp.isin(drop)].reset_index(drop=True)

    class Client:
        def __init__(self, bump=None): self.bump = bump
        def fetch_closed(self, sym, tf):
            return mk({"1m": 60, "5m": 300, "15m": 900}[tf], drop=(end - 300,) if tf == "1m" else (),
                      high_bump=self.bump if tf == "5m" else None)
    r = ShortMTFRunner(tmp_path / "g.sqlite3", client=Client())
    r.broker.open_short("x", "BTCUSDT", 100.0, 1.0, 101.0, end - 600)
    out = r.run_once(["BTCUSDT"])[0]["action"]
    assert out != "STOP_DATA_GAP" and "BTCUSDT" in r.broker.positions()
    # same gap but the covering 5m high crossed the stop -> must be stopped
    r2 = ShortMTFRunner(tmp_path / "g2.sqlite3", client=Client(bump=(end - 300 - 300 % 300, 102.0)))
    r2.broker.open_short("x", "BTCUSDT", 100.0, 1.0, 101.0, end - 600)
    assert r2.run_once(["BTCUSDT"])[0]["action"] == "PAPER_SHORT_STOP"
    assert "BTCUSDT" not in r2.broker.positions()
