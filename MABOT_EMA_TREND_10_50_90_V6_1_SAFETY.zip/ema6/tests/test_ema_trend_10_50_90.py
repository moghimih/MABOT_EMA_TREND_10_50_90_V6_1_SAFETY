import numpy as np
import pandas as pd
import pytest
from strategies.ema_trend_10_50_90 import (EMAConfig, calculate_indicators, evaluate,
                                            calculate_short_quantity, last_contiguous)


def candles(n=240):
    ts = np.arange(n, dtype=np.int64) * 900 + 1_700_000_000
    close = 100 + np.sin(np.arange(n) / 8) * 2 + np.arange(n) * 0.015
    op = np.r_[close[0], close[:-1]]
    return pd.DataFrame({'timestamp': ts, 'open': op, 'high': np.maximum(op, close) + 0.8,
                         'low': np.minimum(op, close) - 0.8, 'close': close, 'volume': np.ones(n)})


def regime_change(n_up=300, n_dn=300, seed=3, vol=0.0012):
    rng = np.random.default_rng(seed)
    r = np.r_[np.full(n_up, 0.0006), np.full(n_dn, -0.0009)] + rng.normal(0, vol, n_up + n_dn)
    c = 100 * np.exp(np.cumsum(r)); o = np.r_[100, c[:-1]]
    n = len(c)
    return pd.DataFrame({'timestamp': 1_700_000_000 + np.arange(n) * 900, 'open': o,
                         'high': np.maximum(o, c) * 1.0004, 'low': np.minimum(o, c) * 0.9996,
                         'close': c, 'volume': np.ones(n)})


def test_indicators_calculated_and_stoch_bounded():
    out = calculate_indicators(candles())
    assert {'ema10', 'ema50', 'ema90', 'atr14', 'stoch_k', 'stoch_d'} <= set(out)
    assert out.stoch_k.dropna().between(0, 100).all()


def test_indicators_match_independent_reference():
    x = candles(300); out = calculate_indicators(x)
    c = x.close.to_numpy(); a = 2 / 11; e = [c[0]]
    for v in c[1:]: e.append(a * v + (1 - a) * e[-1])
    assert np.allclose(np.array(e)[10:], out.ema10.to_numpy()[10:])
    h, l = x.high.to_numpy(), x.low.to_numpy()
    k = [100 * (c[i] - l[i-13:i+1].min()) / (h[i-13:i+1].max() - l[i-13:i+1].min()) for i in range(13, 300)]
    assert np.allclose(k, out.stoch_k.to_numpy()[13:])


def test_warmup_returns_wait():
    assert evaluate(candles(60))['ready'] is False


def test_gap_uses_only_latest_contiguous_segment_never_bridges():
    x = candles(300); x.loc[120:, 'timestamp'] += 900
    seg = last_contiguous(x)
    assert len(seg) == 180 and seg.timestamp.diff().dropna().eq(900).all()
    assert evaluate(x)['ready'] is True           # 180 >= warm-up
    short = candles(300); short.loc[250:, 'timestamp'] += 900
    assert evaluate(short)['ready'] is False       # only 50 bars after the hole -> WAIT, no crash


def test_short_sizing_respects_caps():
    qty, stop = calculate_short_quantity(1000, 100, 2, EMAConfig())
    assert stop == 105 and qty <= 2.0 and qty * (stop - 100) <= 5.0 + 1e-9


def test_invalid_candle_rejected():
    x = candles(); x.loc[10, 'high'] = 1
    with pytest.raises(ValueError, match='OHLC'):
        calculate_indicators(x)


def test_regime_change_up_to_down_produces_entries():
    """Old logic produced ZERO entries here (stack and fresh-cross were contradictory)."""
    x = regime_change(); hits = []
    for i in range(130, len(x)):
        s = evaluate(x.iloc[:i + 1])
        if s.get('entry_signal'): hits.append(i)
    assert hits, "a clean up->down regime change must be tradable"
    assert min(hits) > 300 - 20                    # only after the turn, never in the uptrend


def test_no_entry_in_pure_uptrend_or_compressed_range():
    up = regime_change(n_up=600, n_dn=0)
    assert not any(evaluate(up.iloc[:i + 1]).get('entry_signal') for i in range(130, len(up)))
    n = 400; rng = np.random.default_rng(1); c = 100 + rng.normal(0, 0.01, n); o = np.r_[100, c[:-1]]
    flat = pd.DataFrame({'timestamp': 1_700_000_000 + np.arange(n) * 900, 'open': o,
                         'high': np.maximum(o, c) + .005, 'low': np.minimum(o, c) - .005, 'close': c, 'volume': 1.0})
    assert not any(evaluate(flat.iloc[:i + 1]).get('entry_signal') for i in range(130, n))


def test_sharp_move_cross_is_rejected():
    x = regime_change(n_up=300, n_dn=0)
    last = float(x.close.iloc[-1]); n = len(x)
    crash = pd.DataFrame({'timestamp': 1_700_000_000 + (n + np.arange(3)) * 900,
                          'open': [last, last * .93, last * .90], 'close': [last * .93, last * .90, last * .895],
                          'high': [last, last * .93, last * .90], 'low': [last * .93, last * .89, last * .89],
                          'volume': 1.0})
    y = pd.concat([x, crash], ignore_index=True)
    outs = [evaluate(y.iloc[:i + 1]) for i in range(n, n + 3)]
    assert not any(o['entry_signal'] for o in outs)
