"""Start independent short-only 1m/5m/15m paper runner and phone dashboard.

The service is paper-only. A process lock prevents two runners from trading the
same SQLite account concurrently. Network sharing is opt-in and visibly warned.
"""
from __future__ import annotations

import argparse
import json
import os
import signal
import socket
import threading
import time
from pathlib import Path

from paper_trading.ops import configure_logging
from paper_trading.short_dashboard import serve
from paper_trading.short_mtf import ShortMTFRunner


def local_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def _acquire_lock(path: Path):
    """Atomically create a per-account lock; never silently run two instances."""
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.write(fd, str(os.getpid()).encode("ascii"))
        return fd
    except FileExistsError as exc:
        try:
            owner = path.read_text(encoding="ascii").strip()
        except OSError:
            owner = "unknown"
        raise RuntimeError(f"Another service may be running (lock={path}, pid={owner}).") from exc


def main():
    p = argparse.ArgumentParser(description="MABOT short-only MTF paper service")
    p.add_argument("--db", default="results/short_mtf.sqlite3")
    p.add_argument("--log-file", default="results/logs/short_mtf.log")
    p.add_argument("--interval", type=int, default=60)
    p.add_argument("--port", type=int, default=8084)
    p.add_argument("--share", action="store_true")
    p.add_argument("--once", action="store_true")
    a = p.parse_args()
    if a.interval < 15:
        p.error("--interval must be >=15 seconds")

    db = Path(a.db)
    db.parent.mkdir(parents=True, exist_ok=True)
    beat = db.parent / (db.stem + "_heartbeat.json")
    lock_path = db.with_suffix(db.suffix + ".service.lock")
    lock_fd = None
    server = None
    stop_event = threading.Event()
    try:
        if not a.once:
            lock_fd = _acquire_lock(lock_path)
        log = configure_logging(a.log_file)
        runner = ShortMTFRunner(db, logger=log)
        print("MABOT SHORT MTF | PAPER ONLY | NO LEVERAGE | NO REAL ORDERS")

        if not a.once:
            host = "0.0.0.0" if a.share else "127.0.0.1"
            if a.share:
                print("WARNING: --share exposes the read-only dashboard to the LAN; use only on a trusted private network/firewall.")
            server = serve(db, beat, host, a.port)
            threading.Thread(target=server.serve_forever, daemon=True).start()
            print(f"Phone dashboard: http://{local_ip()}:{a.port}" if a.share
                  else f"Local dashboard: http://127.0.0.1:{a.port}")

        def request_stop(_signum, _frame):
            stop_event.set()
        for sig_name in ("SIGINT", "SIGTERM"):
            if hasattr(signal, sig_name):
                signal.signal(getattr(signal, sig_name), request_stop)

        while not stop_event.is_set():
            started = time.time()
            try:
                results = runner.run_once()
            except Exception as e:
                log.exception("cycle_error")
                results = [{"action": "CYCLE_ERROR", "error": str(e)}]
            heartbeat = {"time": int(time.time()), "pid": os.getpid(), "results": results}
            tmp = beat.with_suffix(beat.suffix + ".tmp")
            tmp.write_text(json.dumps(heartbeat, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, beat)
            print(time.strftime("%H:%M:%S"), " | ".join(
                f"{r.get('symbol', '-')}:{r.get('action')}" for r in results
            ))
            if a.once:
                break
            stop_event.wait(max(0.0, a.interval - (time.time() - started)))
    finally:
        if server is not None:
            server.shutdown()
            server.server_close()
        if lock_fd is not None:
            os.close(lock_fd)
            try:
                lock_path.unlink()
            except FileNotFoundError:
                pass


if __name__ == "__main__":
    main()
