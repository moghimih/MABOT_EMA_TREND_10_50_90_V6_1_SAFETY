@echo off
cd /d %~dp0
rem Phone dashboard on the same Wi-Fi: open http://<PC-IP>:8085 (read-only, no password: trusted network only)
.venv\Scripts\python.exe -m paper_trading.ema_trend_runner --interval 60 --share
pause
