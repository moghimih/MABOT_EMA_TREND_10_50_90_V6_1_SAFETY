"""MABOT EMA TREND 10/50/90 V6 - short-only signal engine.

Signals use only fully closed 15m candles. Stochastic is exit-only.
This module is intentionally independent of BREAKOUT and Short MTF strategies.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd

REQUIRED = {"timestamp", "open", "high", "low", "close", "volume"}

@dataclass(frozen=True)
class EMAConfig:
    ema_fast: int = 10
    ema_mid: int = 50
    ema_slow: int = 90
    stoch_k: int = 14
    stoch_d: int = 3
    stoch_slowing: int = 1
    atr_period: int = 14
    cross_window: int = 12           # EMA10 must have been above BOTH slower EMAs within this many bars
    fresh_bars: int = 3              # ...and must have completed the drop below BOTH within this many bars
    stoch_exit_window: int = 3
    min_fast_below_atr: float = 0.10 # EMA10 must sit this far below BOTH slower EMAs (not a touch)
    min_spread_atr: float = 0.35     # total EMA10/50/90 spread; below this = range/compressed, no trade
    impulse_range_atr: float = 2.50  # any bar in the cross window this wide = sharp-move cross, rejected
    stop_atr_multiple: float = 2.5
    risk_fraction: float = 0.005
    max_portfolio_risk: float = 0.01
    max_notional_fraction: float = 0.20


def _validate(df: pd.DataFrame) -> pd.DataFrame:
    missing = REQUIRED - set(df.columns)
    if missing:
        raise ValueError(f"Missing candle columns: {sorted(missing)}")
    x = df.copy().sort_values("timestamp").drop_duplicates("timestamp", keep="last").reset_index(drop=True)
    for c in REQUIRED:
        x[c] = pd.to_numeric(x[c], errors="raise")
    vals = x[["timestamp", "open", "high", "low", "close", "volume"]].to_numpy(float)
    if len(x) == 0 or not np.isfinite(vals).all():
        raise ValueError("Candles are empty or contain non-finite values")
    if (x[["open", "high", "low", "close"]] <= 0).any().any() or (x.volume < 0).any():
        raise ValueError("Invalid OHLCV values")
    bad = ((x.high < x.low) | (x.high < x.open) | (x.high < x.close) |
           (x.low > x.open) | (x.low > x.close))
    if bad.any():
        raise ValueError("Invalid OHLC relationships")
    # Do not calculate indicators across missing 15m bars.
    if len(x) > 1 and (x.timestamp.diff().dropna() != 900).any():
        raise ValueError("15m candle gap detected; signals disabled until data is repaired")
    return x


def last_contiguous(candles: pd.DataFrame, seconds: int = 900) -> pd.DataFrame:
    """Latest gap-free run of closed candles. Older data before a hole is ignored,
    never bridged, so indicators are never computed across missing bars."""
    x = candles.copy().sort_values("timestamp").drop_duplicates("timestamp", keep="last").reset_index(drop=True)
    if len(x) < 2:
        return x
    breaks = x.timestamp.diff().fillna(seconds).ne(seconds)
    return x[breaks.cumsum() == breaks.cumsum().iloc[-1]].reset_index(drop=True)


def calculate_indicators(candles: pd.DataFrame, cfg: EMAConfig = EMAConfig()) -> pd.DataFrame:
    x = _validate(candles)
    for name, period in (("ema10", cfg.ema_fast), ("ema50", cfg.ema_mid), ("ema90", cfg.ema_slow)):
        x[name] = x.close.ewm(span=period, adjust=False, min_periods=period).mean()
    prev_close = x.close.shift(1)
    tr = pd.concat([(x.high-x.low), (x.high-prev_close).abs(), (x.low-prev_close).abs()], axis=1).max(axis=1)
    x["atr14"] = tr.ewm(alpha=1/cfg.atr_period, adjust=False, min_periods=cfg.atr_period).mean()
    low_n = x.low.rolling(cfg.stoch_k, min_periods=cfg.stoch_k).min()
    high_n = x.high.rolling(cfg.stoch_k, min_periods=cfg.stoch_k).max()
    denom = (high_n - low_n).replace(0, np.nan)
    raw_k = 100 * (x.close - low_n) / denom
    x["stoch_k"] = raw_k.rolling(cfg.stoch_slowing, min_periods=cfg.stoch_slowing).mean()
    x["stoch_d"] = x.stoch_k.rolling(cfg.stoch_d, min_periods=cfg.stoch_d).mean()
    return x


def _cross_below(a: pd.Series, b: pd.Series) -> pd.Series:
    return (a.shift(1) >= b.shift(1)) & (a < b)

def _cross_above(a: pd.Series, b: pd.Series) -> pd.Series:
    return (a.shift(1) <= b.shift(1)) & (a > b)


def evaluate(candles: pd.DataFrame, cfg: EMAConfig = EMAConfig()) -> dict:
    """Latest closed-bar signal. Only the newest gap-free segment is used."""
    seg = last_contiguous(candles)
    warmup = max(cfg.ema_slow + 2, cfg.stoch_k + cfg.stoch_d + 2, cfg.atr_period + 2)
    if len(seg) < warmup:
        return {"ready": False, "action": "WAIT",
                "reason": f"Warm-up/gap: {len(seg)}/{warmup} contiguous 15m candles"}
    x = calculate_indicators(seg, cfg)
    r = x.iloc[-1]
    if not np.isfinite([r.ema10, r.ema50, r.ema90, r.atr14, r.stoch_k, r.stoch_d]).all() or r.atr14 <= 0:
        return {"ready": False, "action": "WAIT", "reason": "Indicators not ready"}
    n = cfg.cross_window
    above_both_s = (x.ema10 > x.ema50) & (x.ema10 > x.ema90)
    below_both_s = (x.ema10 < x.ema50) & (x.ema10 < x.ema90)
    was_above = bool(above_both_s.tail(n).any())
    started = not bool(below_both_s.iloc[-1 - cfg.fresh_bars]) if len(x) > cfg.fresh_bars else False
    crossed_both = bool(below_both_s.iloc[-1] and was_above and started)
    below_both = bool(r.ema10 < r.ema50 and r.ema10 < r.ema90)
    fast_below_atr = float((min(r.ema50, r.ema90) - r.ema10) / r.atr14)
    spread_atr = float((max(r.ema10, r.ema50, r.ema90) - min(r.ema10, r.ema50, r.ema90)) / r.atr14)
    clear = fast_below_atr >= cfg.min_fast_below_atr
    not_range = spread_atr >= cfg.min_spread_atr
    window = x.tail(n)
    impulse_atr = float(((window.high - window.low) / r.atr14).max())
    impulse = impulse_atr >= cfg.impulse_range_atr
    entry_signal = bool(below_both and crossed_both and clear and not_range and not impulse)

    # Stochastic is exit-only. EMA10 must cross back above EMA50 and Stochastic %K
    # must cross above %D inside the same short closed-bar window.
    ema_reversal = _cross_above(x.ema10, x.ema50)
    stoch_bull = _cross_above(x.stoch_k, x.stoch_d)
    exit_signal = bool(ema_reversal.tail(cfg.stoch_exit_window).any() and
                       stoch_bull.tail(cfg.stoch_exit_window).any())
    reason = ("EMA10 crossed below EMA50+EMA90, clear and not sharp" if entry_signal else
              ("EMA10 bullish reversal + Stochastic bullish cross" if exit_signal else "No confirmed setup"))
    return {
        "ready": True, "timestamp": int(r.timestamp) + 900, "price": float(r.close), "atr": float(r.atr14),
        "ema10": float(r.ema10), "ema50": float(r.ema50), "ema90": float(r.ema90),
        "stoch_k": float(r.stoch_k), "stoch_d": float(r.stoch_d),
        "below_both": below_both, "crossed_both": crossed_both,
        "fast_below_atr": fast_below_atr, "spread_atr": spread_atr,
        "impulse_range_atr": impulse_atr, "impulse_blocked": impulse,
        "range_blocked": not not_range,
        "entry_signal": entry_signal, "exit_signal": exit_signal,
        "action": "SHORT_ENTRY" if entry_signal else ("SHORT_EXIT" if exit_signal else "HOLD"),
        "reason": reason,
    }


def calculate_short_quantity(equity: float, entry: float, atr: float,
                             cfg: EMAConfig = EMAConfig()) -> tuple[float, float]:
    """ATR protective stop and conservative risk/notional-capped short quantity."""
    if not all(np.isfinite(v) and v > 0 for v in (equity, entry, atr)):
        raise ValueError("equity, entry and ATR must be positive finite values")
    stop = entry + cfg.stop_atr_multiple * atr
    risk_budget = equity * cfg.risk_fraction
    qty_by_risk = risk_budget / (stop-entry)
    qty_by_notional = equity * cfg.max_notional_fraction / entry
    return max(0.0, min(qty_by_risk, qty_by_notional)), stop
