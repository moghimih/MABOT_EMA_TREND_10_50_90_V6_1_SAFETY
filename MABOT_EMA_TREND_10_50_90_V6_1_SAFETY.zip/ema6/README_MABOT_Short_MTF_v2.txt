MABOT Short MTF v2 — safety patch (Paper Trading only)

Files
- paper_trading/short_mtf.py: fixes short portfolio-risk aggregation and checks hard stops on each newly closed 1-minute candle.
- paper_trading/market_data.py: accepts legitimate zero-volume candles while rejecting negative/non-finite volume and invalid OHLC values.
- tests/test_short_mtf_v2_safety.py: focused regression tests for the safety changes.

Install
1. Stop the bot before replacing files.
2. Back up the two existing source files:
   copy paper_trading\short_mtf.py paper_trading\short_mtf.py.bak
   copy paper_trading\market_data.py paper_trading\market_data.py.bak
3. Extract this ZIP into the MABOT project root and allow it to overwrite the two files.
4. Do not delete or replace the existing SQLite database.
5. From the project root, run:
   .venv\Scripts\python.exe -m pytest -q tests\test_short_mtf_v2_safety.py
6. If those tests pass, run the full existing suite:
   .venv\Scripts\python.exe -m pytest -q
7. Only after both checks pass, resume paper trading and inspect the logs/database.

Important
- This patch does not change entry indicators or strategy parameters.
- It does not add exchange order placement. The market-data client remains public/read-only.
- Existing positions, if any, are not auto-migrated. The patch preserves the current database and adds a stop_checks table.
- The 1m stop model uses closed candles and a conservative gap-open reference price, then applies the existing paper slippage model.
- This is a code-safety improvement, not evidence of profitability. Continue paper trading only.
