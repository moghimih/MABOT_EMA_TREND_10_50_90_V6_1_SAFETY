"""EMA TREND 10/50/90 V6 paper runner (short-only, 15m). Public candles only; no order API.

V6 safety model:
  * Every closed 15m bar after entry is checked against the stop, in order,
    independent of whether the signal engine is ready (state in ema_stop_checks).
  * A missing 15m bar is verified from 5m candles; if even that is impossible the
    bar is skipped with a persistent alert instead of locking the position forever.
  * After a stop, no new entry on that same bar (ema_last_stop).
  * Equity is marked with the last known price of every symbol (ema_marks).
  * Portfolio risk cap, single-instance lock, heartbeat, retries.
"""
from __future__ import annotations
import argparse, json, logging, math, os, signal, sqlite3, threading, time
from pathlib import Path

import pandas as pd
from config.settings import SYMBOLS, INITIAL_CAPITAL, FEE_RATE, SLIPPAGE_RATE
from paper_trading.market_data import NobitexPublicDataClient
from paper_trading.ops import retry_call
from paper_trading.short_mtf import ShortPaperBroker, _remaining_short_risk
from strategies.ema_trend_10_50_90 import EMAConfig, evaluate, calculate_short_quantity

BAR = 900
MAX_POSITIONS = 2


class EMATrendPaperRunner:
    def __init__(self, db_path="results/ema_trend_10_50_90_v6.sqlite3", client=None,
                 config=EMAConfig(), symbols=None, logger=None):
        self.db_path = str(db_path); self.client = client or NobitexPublicDataClient()
        self.cfg = config; self.symbols = list(symbols or SYMBOLS); self.log = logger or logging.getLogger("ema")
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self.broker = ShortPaperBroker(self.db_path, INITIAL_CAPITAL, FEE_RATE, SLIPPAGE_RATE)
        with sqlite3.connect(self.db_path) as con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS ema_processed(symbol TEXT, bar_ts INTEGER, action TEXT, PRIMARY KEY(symbol,bar_ts));
            CREATE TABLE IF NOT EXISTS ema_status(symbol TEXT PRIMARY KEY, bar_ts INTEGER, action TEXT, reason TEXT, price REAL, ema10 REAL, ema50 REAL, ema90 REAL, stoch_k REAL, stoch_d REAL, updated_at INTEGER);
            CREATE TABLE IF NOT EXISTS ema_snapshots(ts INTEGER PRIMARY KEY, cash REAL, equity REAL, open_positions INTEGER);
            CREATE TABLE IF NOT EXISTS ema_stop_checks(symbol TEXT, bar_ts INTEGER, action TEXT, PRIMARY KEY(symbol,bar_ts));
            CREATE TABLE IF NOT EXISTS ema_marks(symbol TEXT PRIMARY KEY, price REAL, ts INTEGER);
            CREATE TABLE IF NOT EXISTS ema_last_stop(symbol TEXT PRIMARY KEY, close_ts INTEGER);
            CREATE TABLE IF NOT EXISTS ema_alerts(symbol TEXT PRIMARY KEY, ts INTEGER, state TEXT, reason TEXT);
            """)

    # -- small db helpers -------------------------------------------------
    def _q(self, sql, args=()):
        with sqlite3.connect(self.db_path) as con:
            return con.execute(sql, args).fetchall()

    def _x(self, sql, args=()):
        with sqlite3.connect(self.db_path) as con:
            con.execute(sql, args)

    def _processed(self, symbol, bar_ts):
        return bool(self._q("SELECT 1 FROM ema_processed WHERE symbol=? AND bar_ts=?", (symbol, int(bar_ts))))

    def _mark_processed(self, symbol, ts, action):
        self._x("INSERT OR REPLACE INTO ema_processed VALUES(?,?,?)", (symbol, int(ts), action))

    def _set_mark(self, symbol, price, ts):
        self._x("INSERT OR REPLACE INTO ema_marks VALUES(?,?,?)", (symbol, float(price), int(ts)))

    def marks(self):
        return {s: p for s, p in self._q("SELECT symbol,price FROM ema_marks")}

    def _alert(self, symbol, state, reason):
        self._x("INSERT OR REPLACE INTO ema_alerts VALUES(?,?,?,?)", (symbol, int(time.time()), state, str(reason)[:300]))

    def _clear_alert(self, symbol):
        self._x("DELETE FROM ema_alerts WHERE symbol=?", (symbol,))

    # -- stop monitoring (independent of signal readiness) ---------------
    def _monitor_stops(self, symbol, candles: pd.DataFrame):
        """Check every closed bar after entry, oldest first. Returns 'PAPER_STOP' or None."""
        pos = self.broker.positions().get(symbol)
        if not pos:
            return None
        last = self._q("SELECT MAX(bar_ts) FROM ema_stop_checks WHERE symbol=?", (symbol,))[0][0]
        first_expected = int(pos["opened_at"]) + BAR           # first bar fully after the entry bar
        # a bar checked before this position existed must not count
        expected = max(first_expected, (int(last) + BAR) if last is not None and int(last) >= first_expected else first_expected)
        bars = {int(r.timestamp): r for r in candles.itertuples()}
        if not bars:
            return None
        last_bar = max(bars)
        five = None
        for slot in range(expected, last_bar + BAR, BAR):
            pos = self.broker.positions().get(symbol)
            if not pos:
                return None
            stop = float(pos["stop"]); bar = bars.get(slot); action = "CHECKED"
            if bar is not None:
                hit = float(bar.high) >= stop; ref = max(float(bar.open), stop)
            else:
                if five is None:
                    try:
                        five = retry_call(lambda: self.client.fetch_closed(symbol, "5m"), attempts=3)
                    except Exception:
                        five = pd.DataFrame(columns=["timestamp", "high"])
                part = five[(five.timestamp >= slot) & (five.timestamp < slot + BAR)].copy()
                expected_5m = [slot, slot + 300, slot + 600]
                actual_5m = sorted(int(t) for t in part.timestamp.tolist())
                # A partial 5m response cannot prove that the 15m high stayed below
                # the stop. Treat incomplete coverage as an unsafe data gap.
                if actual_5m != expected_5m:
                    latest = candles.sort_values("timestamp").iloc[-1]
                    # Never model the emergency cover below the stop level when
                    # the missing interval could have touched or crossed it.
                    cover_ref = max(stop, float(latest.close))
                    self._alert(
                        symbol, "STOP_DATA_GAP_COVERED",
                        f"15m bar {slot} lacked complete 5m coverage; position conservatively covered "
                        f"at latest available 15m close {cover_ref}"
                    )
                    if self.broker.cover(
                        f"{symbol}:{slot}:EMA_GAP_COVER", symbol, cover_ref,
                        int(latest.timestamp) + BAR, "EMA_STOP_DATA_GAP_EXIT"
                    ):
                        self._x("INSERT OR REPLACE INTO ema_stop_checks VALUES(?,?,?)",
                                (symbol, slot, "GAP_COVERED"))
                        self._x("INSERT OR REPLACE INTO ema_last_stop VALUES(?,?)",
                                (symbol, int(latest.timestamp) + BAR))
                        return "PAPER_GAP_EXIT"
                    # If the close failed (e.g. concurrent state change), keep an
                    # explicit alert and do not pretend the missing interval was checked.
                    self._alert(symbol, "STOP_MONITOR_UNAVAILABLE",
                                f"Could not conservatively cover after unverifiable bar {slot}")
                    return "STOP_MONITOR_UNAVAILABLE"
                hit = float(part.high.max()) >= stop
                ref = stop
                action = "CHECKED_5M_FALLBACK"
            if hit:
                if self.broker.cover(f"{symbol}:{slot}:EMA_STOP", symbol, ref, slot + BAR, "EMA_SHORT_STOP"):
                    self._x("INSERT OR REPLACE INTO ema_stop_checks VALUES(?,?,?)", (symbol, slot, "STOPPED"))
                    self._x("INSERT OR REPLACE INTO ema_last_stop VALUES(?,?)", (symbol, slot + BAR))
                    return "PAPER_STOP"
            self._x("INSERT OR IGNORE INTO ema_stop_checks VALUES(?,?,?)", (symbol, slot, action))
        return None

    # -- main cycle ------------------------------------------------------
    def run_once(self):
        results = []
        for symbol in self.symbols:
            try:
                results.append(self._run_symbol(symbol))
            except Exception as exc:
                self.log.exception("EMA cycle failed for %s", symbol)
                if self.broker.positions().get(symbol):
                    self._alert(symbol, "STOP_MONITOR_UNAVAILABLE", f"{type(exc).__name__}: {exc}")
                results.append({"symbol": symbol, "action": "DATA_OR_PROCESSING_ERROR",
                                "reason": f"{type(exc).__name__}: {exc}"})
        marks = self.marks()
        self._x("INSERT OR REPLACE INTO ema_snapshots VALUES(?,?,?,?)",
                (int(time.time()), self.broker.cash, self.broker.equity(marks), len(self.broker.positions())))
        return results

    def _run_symbol(self, symbol):
        candles = retry_call(lambda: self.client.fetch_closed(symbol, "15m"), attempts=3)
        last = candles.iloc[-1]
        self._set_mark(symbol, last.close, int(last.timestamp) + BAR)
        stop_action = self._monitor_stops(symbol, candles)
        alert_states = {row[0] for row in self._q(
            "SELECT state FROM ema_alerts WHERE symbol=?", (symbol,)
        )}
        # Keep a data-gap forced-exit alert visible after the position is closed;
        # ordinary transient alerts are cleared once there is no open exposure.
        if not self.broker.positions().get(symbol) and "STOP_DATA_GAP_COVERED" not in alert_states:
            self._clear_alert(symbol)
        elif self.broker.positions().get(symbol) and "STOP_BAR_UNVERIFIABLE" not in alert_states:
            self._clear_alert(symbol)
        sig = evaluate(candles, self.cfg)
        if not sig.get("ready"):
            return {"symbol": symbol, "action": stop_action or "WAIT", "reason": sig.get("reason")}
        ts = int(sig["timestamp"]); price = float(sig["price"])
        self._x("INSERT OR REPLACE INTO ema_status VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (symbol, ts, sig["action"], sig["reason"], price, sig["ema10"], sig["ema50"], sig["ema90"],
                 sig["stoch_k"], sig["stoch_d"], int(time.time())))
        if stop_action:
            return {"symbol": symbol, "action": stop_action, "timestamp": ts}
        pos = self.broker.positions().get(symbol)
        if pos:
            if sig["exit_signal"] and not self._processed(symbol, ts):
                self.broker.cover(f"{symbol}:{ts}:EMA_EXIT", symbol, price, ts, "EMA_STOCH_EXIT")
                self._mark_processed(symbol, ts, "PAPER_EXIT")
                return {"symbol": symbol, "action": "PAPER_EXIT", "price": price}
            return {"symbol": symbol, "action": "HOLD", "price": price, "reason": sig["reason"]}
        if not (sig["entry_signal"] and not self._processed(symbol, ts)):
            return {"symbol": symbol, "action": "NO_SIGNAL", "price": price, "reason": sig["reason"]}
        # entry candidate ------------------------------------------------
        self._mark_processed(symbol, ts, "ENTRY_EVALUATED")
        stopped = self._q("SELECT close_ts FROM ema_last_stop WHERE symbol=?", (symbol,))
        if stopped and ts <= int(stopped[0][0]):
            return {"symbol": symbol, "action": "SKIP_SAME_BAR_AS_STOP"}
        if len(self.broker.positions()) >= MAX_POSITIONS:
            return {"symbol": symbol, "action": "SKIP_MAX_POSITIONS"}
        equity = self.broker.equity(self.marks())
        qty, stop = calculate_short_quantity(equity, price, float(sig["atr"]), self.cfg)
        est = price * (1 - SLIPPAGE_RATE)
        per_unit = max(0.0, stop - est) + est * (2 * FEE_RATE + 2 * SLIPPAGE_RATE)
        open_risk = _remaining_short_risk(self.broker.positions(), FEE_RATE, SLIPPAGE_RATE)
        room = equity * self.cfg.max_portfolio_risk - open_risk
        qty = min(qty, equity * self.cfg.risk_fraction / max(per_unit, 1e-12), room / max(per_unit, 1e-12))
        if not (qty > 0 and math.isfinite(qty)):
            return {"symbol": symbol, "action": "SKIP_RISK_LIMIT"}
        opened = self.broker.open_short(f"{symbol}:{ts}:EMA_ENTRY", symbol, price, qty, stop, ts - BAR)
        if opened:
            self._mark_processed(symbol, ts, "PAPER_SHORT_OPEN")
        return {"symbol": symbol, "action": "PAPER_SHORT_OPEN" if opened else "DUPLICATE_IGNORED",
                "price": price, "quantity": qty, "stop": stop}


def _acquire_lock(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.write(fd, str(os.getpid()).encode()); return fd
    except FileExistsError as exc:
        raise RuntimeError(f"Another runner may be using this DB (lock={path}). "
                           f"If none is running, delete the lock file.") from exc


def main():
    p = argparse.ArgumentParser(description="MABOT EMA TREND 10/50/90 V6 - PAPER ONLY")
    p.add_argument("--interval", type=int, default=60)
    p.add_argument("--db", default="results/ema_trend_10_50_90_v6.sqlite3")
    p.add_argument("--port", type=int, default=8085)
    p.add_argument("--share", action="store_true", help="expose read-only dashboard on LAN (phone)")
    p.add_argument("--no-dashboard", action="store_true")
    p.add_argument("--once", action="store_true")
    a = p.parse_args()
    if a.interval < 10: p.error("--interval must be at least 10 seconds")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    db = Path(a.db); beat = db.parent / (db.stem + "_heartbeat.json")
    lock = db.with_suffix(db.suffix + ".lock"); fd = None; server = None
    stop = threading.Event()
    try:
        if not a.once: fd = _acquire_lock(lock)
        runner = EMATrendPaperRunner(a.db)
        print("MABOT EMA 10/50/90 | PAPER ONLY | NO REAL ORDERS")
        if not a.once and not a.no_dashboard:
            from paper_trading.ema_dashboard import serve
            server = serve(a.db, beat, "0.0.0.0" if a.share else "127.0.0.1", a.port)
            threading.Thread(target=server.serve_forever, daemon=True).start()
            print(("WARNING: LAN dashboard (no password) -> " if a.share else "Dashboard -> ") + f"http://127.0.0.1:{a.port}")
        for name in ("SIGINT", "SIGTERM"):
            if hasattr(signal, name): signal.signal(getattr(signal, name), lambda *_: stop.set())
        while not stop.is_set():
            t0 = time.time()
            try: res = runner.run_once()
            except Exception as e:
                logging.exception("cycle_error"); res = [{"action": "CYCLE_ERROR", "reason": str(e)}]
            tmp = beat.with_suffix(".tmp"); tmp.write_text(json.dumps({"time": int(time.time()), "results": res}, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, beat)
            for item in res: logging.info("%s", item)
            if a.once: break
            stop.wait(max(0.0, a.interval - (time.time() - t0)))
    finally:
        if server: server.shutdown(); server.server_close()
        if fd is not None:
            os.close(fd)
            try: lock.unlink()
            except FileNotFoundError: pass


if __name__ == "__main__": main()
